﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UiPath.Studio.Activities.Api;
using UiPath.Studio.Activities.Api.Analyzer;
using UiPath.Studio.Analyzer.Models;
using UiPath.Studio.Activities.Api.Analyzer.Rules;


namespace MaximumVariableLength
{
    public class RuleRepository : IRegisterAnalyzerConfiguration
    {
        public void Initialize(IAnalyzerConfigurationService workflowAnalyzerConfigService)
        {
            if (!workflowAnalyzerConfigService.HasFeature("WorkflowAnalyzerV4"))
                return;

            var forbiddenStringRule = new Rule<IActivityModel>("NotAllowedVariables", "DE-USG-001", InspectVariableForString);
            
            forbiddenStringRule.DefaultErrorLevel = System.Diagnostics.TraceLevel.Error;
            
            forbiddenStringRule.Parameters.Add("string_in_variable", new Parameter()
            {
                DefaultValue = "var",
                Key = "string_in_variable",
                LocalizedDisplayName = "Invalid String",
            });

            workflowAnalyzerConfigService.AddRule<IActivityModel>(forbiddenStringRule);

            throw new NotImplementedException();
        }
        private InspectionResult InspectVariableForString(IActivityModel activityToInspect, Rule configuredRule)
        {
            var configuredString = configuredRule.Parameters["string_in_variable"]?.Value;

            if (string.IsNullOrEmpty(configuredString))
            {
                return new InspectionResult() { HasErrors = false };
            }
            if (activityToInspect.Variables.Count == 0)
            {
                return new InspectionResult() { HasErrors = false };
            }

            var messageList = new List<InspectionMessage>();

            foreach(var variable in activityToInspect.Variables)
            {
                if (variable.DisplayName.Contains(configuredString))
                {
                    messageList.Add(new InspectionMessage()
                    {
                        Message = $"Variable {variable.DisplayName} contains an invalid string {configuredString}"
                    });
                }
            }

            if(messageList.Count > 0)
            {
                return new InspectionResult()
                {
                    HasErrors = true,
                    InspectionMessages = messageList,
                    RecommendationMessage = "Fix your variable naming",
                    ErrorLevel = configuredRule.ErrorLevel
                };
            }

            return new InspectionResult { HasErrors = false };
        }
    }
}
